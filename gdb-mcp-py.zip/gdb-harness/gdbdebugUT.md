# GDB 调试总入口

> 本文档是 GDB 调试任务的入口文件，定义调试流程和场景指导。

---

## 调试流程

### 1. 准备

**启动 MCP 服务（如果未运行）**
```bash
python3.11 /home/00359039/Desktop/gdb-claw/gdb-mcp-py/server.py
```

服务默认监听 `http://localhost:8000`

### 2. 创建会话

**调用 `start_session`**

```
工具: start_session
参数:
  working_directory: "/path/to/project"  # 项目根目录绝对路径
```

**返回**
```json
{
  "session_id": "fc89f075-44bc-41c9-a26a-5c431a79f013",
  "status": "可用"
}
```

### 3. 选择场景
对应场景需要的参数需要根据用户需求或自主分析获得后使用MCP的execute_command工具进行gdb的参数添加。
#### 常用交互式GDB命令参考
```json
"command":"file ./a.out"          # 加载可执行程序
"command":"break main"            # 函数断点
"command":"run arg1 arg2"         # 带参数启动程序
"command":"info registers"        # 查看寄存器
"command":"print global_var"      # 打印变量
"command":"next"                  # 单步跳过
"command":"step"                  # 单步进入
"command":"bt"                    # 打印调用栈
```

#### 常用MI2机器指令参考
```json
"command":"-file-exec-and-symbols ./a.out"  # MI加载程序
"command":"-break-insert main"              # MI设置断点
"command":"-exec-run"                       # MI运行程序
"command":"-exec-next"                      # MI单步跳过
"command":"-stack-list-frames"              # MI获取调用栈结构化数据
"command":"-data-list-register-values x"    # MI读取寄存器十六进制值
```
根据调试任务类型，进入对应 Skill 文件获取具体 GDB 命令：
| 任务类型 | Skill 文件 |
|----------|-----------|
| 追踪变量来源、验证断点、定位 Bug | [skills/gdb-general-trace.md](./skills/gdb-general-trace.md) |
| 分析 UT 失败原因，修复测试用例 | [skills/gdb-ut-fix.md](./skills/gdb-ut-fix.md) |
| 验证 UT 执行路径与测试意图一致性 | [skills/gdb-ut-validate.md](./skills/gdb-ut-validate.md) |

### 4. 结束会话

**调用 `close_session`**

```
工具: close_session
参数:
  session_id: "fc89f075-44bc-41c9-a26a-5c431a79f013"
```

---

## 完整调用示例
所有对GDB的调试调用都应该遵守这些格式

### 初始化 MCP 连接

```bash
curl -N --http1.1 -D - -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-d '{
    "jsonrpc":"2.0",
    "id":1,
    "method":"initialize",
    "params":{
        "protocolVersion":"2024-11-05",
        "capabilities":{},
        "clientInfo":{"name":"client","version":"1.0"}
    }
}'
```

**提取响应 Header 中的 `mcp-session-id`**

### 创建 GDB 会话

```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":2,
    "method":"tools/call",
    "params":{
        "name":"start_session",
        "arguments":{"working_directory":"/path/to/project"}
    }
}'
```

### 执行 GDB 命令

```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":3,
    "method":"tools/call",
    "params":{
        "name":"execute_command",
        "arguments":{
            "session_id":"<gdb-session-id>",
            "command":"file ./build/test_ut"
        }
    }
}'
```

### 关闭会话

```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":4,
    "method":"tools/call",
    "params":{
        "name":"close_session",
        "arguments":{"session_id":"<gdb-session-id>"}
    }
}'
```

---

## 标准调试流程

### 初始化 GDB 环境

```python
execute_command(session_id, "set pagination off")
execute_command(session_id, "set breakpoint pending on")
execute_command(session_id, "set print pretty on")
```

### 加载程序

在使用 gdbMCP 时，GDB 会话通过 `start_session` 启动后，**通常需要先加载可执行文件，再设置运行参数**（相当于传统 `gdb --args` 的功能），最后才执行 `run` 启动程序。  
典型的调试第一步是加载可执行文件并设置参数，例如要对测试程序 `uac_ut_feature` 运行指定的 Google Test 用例：

```python
execute_command(session_id, "file ./uac_ut_feature")
execute_command(session_id, "set args --gtest_filter=TestClass.TestMethod")
execute_command(session_id, "break function_name")
execute_command(session_id, "run")
```

### 结束调试

```python
execute_command(session_id, "quit")
close_session(session_id)
```

---
## 关键注意事项

1. **终端会话限制**  
   `mcp-session-id` 绑定当前curl终端连接，新开终端需要重新执行 `initialize`，旧GDB会话会失效丢失。  
2. **curl必带参数**  
   - `-N`：关闭输出缓冲，适配SSE流式响应，否则请求卡死无返回  
   - `--http1.1`：强制HTTP1.1，避免http2流式兼容异常  
3. **请求头不可缺失**  
   - `Content-Type: application/json`  
   - `Accept: application/json, text/event-stream`（缺失会报406 Not Acceptable）  
   - `mcp-session-id: xxx`（缺失会话关联，工具调用异常）  
4. **GDB MI协议核心特性**  
   - 会话持久：多次调用 `execute_command` 共享同一个GDB进程，断点、程序运行状态全部保留  
   - 无调用次数限制：单GDB会话可循环执行上千条命令，无需重复创建会话  
   - 混合兼容：MI机器指令与人用交互式命令可任意穿插使用  
5. **日志排查**  
   服务端运行日志路径：`/tmp/gdb_mcp_server.log`，可查看GDB进程启动、PID、崩溃信息。  
6. **错误码说明**  
   - 404：接口路径错误，必须使用 `/mcp`  
   - 406：Accept头缺少 `text/event-stream`  
   - 会话不存在：`mcp-session-id` 或GDB session_id填写错误、连接已失效  

---

## 完整执行成功标识

1. HTTP返回 `200 OK`，`content-type: text/event-stream`  
2. 输出包含 `event: message` 行  
3. JSON返回 `isError:false`  
4. `output` 字段末尾带有 `(gdb)` 提示符，代表GDB命令执行完毕  
5. MI指令返回结构化 `^done` / `^running` / `^error` 标准MI前缀输出  

