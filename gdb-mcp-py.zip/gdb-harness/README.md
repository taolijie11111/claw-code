# GDB Harness for Claude Code

本目录为 Claude Code 提供 GDB 调试能力的完整 Harness，使 Agent 能够通过 `gdb-mcp-py` 工具执行真实的 GDB 调试任务。

---

## 架构概览

```
gdb-harness/
├── README.md                    # 本文档，入口
├── gdbdebugUT.md               # 调试总入口，整合完整流程
├── skills/                      # 场景目录
│   ├── gdb-general-trace.md    # 通用代码追踪场景
│   ├── gdb-ut-fix.md           # UT 失败用例修复场景
│   └── gdb-ut-validate.md      # UT 路径验证场景

```

---

## 快速开始

1. **阅读总入口文档**: [gdbdebugUT.md](./gdbdebugUT.md)
2. **根据任务类型选择场景**:
   - 通用追踪 → [skills/gdb-general-trace.md](./skills/gdb-general-trace.md)
   - UT 修复 → [skills/gdb-ut-fix.md](./skills/gdb-ut-fix.md)
   - UT 验证 → [skills/gdb-ut-validate.md](./skills/gdb-ut-validate.md)
3. **启动 MCP 服务**（如果未运行）:
   ```bash
   python3.11 /home/00359039/Desktop/gdb-claw/gdb-mcp-py/server.py
   ```
4. **按照流程执行调试**

---

## 核心概念

### GDB 会话生命周期

```
1. start_session(working_directory)  → session_id
2. 循环 execute_command(session_id, command)
3. close_session(session_id)
```

### Claude Code 在调试中的角色

Claude Code 充当 **自动化调试专家**，通过迭代循环完成调试任务：

```
分析任务 → 决定下一步 GDB 命令 → 执行 → 观察输出 → 总结状态 → 决策下一步 → ...
```

---

## 场景覆盖

| 场景 | 文件 | 用途 |
|------|------|------|
| 通用代码追踪 | `skills/gdb-general-trace.md` | 追踪变量来源、验证断点、定位 bug |
| UT 失败修复 | `skills/gdb-ut-fix.md` | 分析 UT 失败原因，修复测试用例 |
| UT 路径验证 | `skills/gdb-ut-validate.md` | 验证实际执行路径是否匹配测试意图 |

---

## 从旧项目迁移

旧项目 `MetaGPT-main/project/tool/gdb` 的能力映射：

| 旧模块 | 新 Harness |
|--------|-----------|
| `gdb_auto_trace.py` | `skills/gdb-general-trace.md` |
| `gdb_fixed_ut.py` | `skills/gdb-ut-fix.md` |
| `gdb_judge_ut.py` | `skills/gdb-ut-validate.md` |
| `GdbController` | MCP `execute_command` |
| `parse_commands()` | Agent 直接解析 LLM 输出 |
| `summarize_gdb_output()` | Agent 内化上下文 |

---

## 安全边界

- 禁止修改被测代码和编译产物
- 禁止执行 `kill`、`detach` 等破坏性命令
- 禁止访问工作目录外的路径