# UT 失败用例修复场景

> 本 Skill 覆盖 UT 失败后的调试分析和用例修复任务。
> 详细流程请参考总入口 [gdbdebugUT.md](../gdbdebugUT.md)。

---

## 适用场景

- UT 用例执行失败（EXPECT 断言不符）
- 需要分析被测函数的实际执行路径
- 需要修改测试用例使其正确覆盖目标代码

---

## 输入参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `testcase` | 测试用例名 | `Test_MbsSwitchDisabled` |
| `function_name` | 被测函数名 | `JudgeUeHasBeenSelectedByMbsMII` |
| `failed_info` | 失败输出 | "Expected X, Got Y" |

---

## 调试流程

### 单步追踪执行路径

循环执行以下步骤：
1. `step` - 单步进入
2. `print` 当前关键变量
3. `list` 查看当前代码行
4. 判断是否与预期路径一致
5. 重复直到函数结束

### 关键观察点

```gdb
# 每步后观察
execute_command(session_id, "print variable_name")
execute_command(session_id, "print *struct_ptr")
execute_command(session_id, "info locals")

# 使用 list 确认代码行
execute_command(session_id, "list")
```

---

## 常见失败原因及处理

### 1. 静态函数 Mock 失效

识别: 函数调用未进入被 Mock 的静态函数

处理:
- 删除原有 Mock 代码
- 使用 extern 控制依赖的全局变量
- 通过 `list` 命令确认变量类型

### 2. 变量值不符合预期

识别: `print` 显示的值与用例设置不一致

处理:
- 使用 `bt` 确认调用栈
- 追踪变量来源
- 检查是否有其他代码修改了该变量

### 3. 执行路径偏差

识别: 实际路径与测试意图不符

处理:
- 逐行 `step`，确认每步执行的分支
- 对比函数源码确认预期分支
- 调整用例设置使进入正确分支

---

## 命令决策原则

### 优先级排序

1. **信息获取优先** — `bt`、`info locals`、`print` 优先于控制流命令
2. **最小干扰** — 用最少的命令获取足够信息
3. **批量执行** — 同一断点处可一次执行多个观察命令
4. **条件断点** — 复杂场景使用条件断点减少停顿次数

---

## 安全边界

- **禁止修改内存或变量值**: `set var x = 10`
- **禁止执行 shell 命令**: `shell rm -rf /`
- **禁止加载工作目录外的二进制**: `file /bin/ls`
- **只允许操作 working_directory 内的文件**

---

## 输出要求

修复完成后输出：

```markdown
## UT 修复报告

### 用例信息
- 测试用例: [TestName]
- 被测函数: [FunctionName]
- 失败原因: [根因分析]

### 调试过程
- 单步执行结果: [路径是否符合预期]
- 关键变量: [变量值是否符合预期]

### 修复方案
- 修改内容: [具体修改]
- 保持测试意图: [确认说明]

### 修复后代码
```cpp
// 完整修复后的用例代码
```
```
