---
name: gdbdebug
description: 本文档是 GDB 调试任务的入口文件，定义调试流程和场景指导。
---

# 标准调试流程

用户提供 `用例名` 和 `工程名`

## 0. 加载工程配置

读取 `projects/{工程名}.json`

### 配置文件结构

```json
{
  "name": "工程名称",
  "description": "工程描述",

  "build": {
    "command": "编译命令",
    "workDir": "编译产物目录（用于调试的 workDir）相对于当前终端的相对路径"
  },

  "run": {
    "command": "运行命令（用 {testcase} 占位符表示用例名）",
    "testcaseParam": "用例参数前缀（testngpp 用，如 -f::）"
  },

  "testRunner": {
    "binary": "测试运行器路径（相对于 workDir）",
    "format": "testngpp | gtest",
    "testSuite": "测试套件路径（testngpp 用，相对于 workDir）",
    "listener": "监听器路径（testngpp 用，相对于 workDir）",
    "fixedArgs": ["固定参数列表（testngpp 用）"],
    "testcaseParam": "用例参数前缀（gtest 用，如 --gtest_filter=）"
  },

  "env": {
    "LD_LIBRARY_PATH": "运行时库路径（相对于 workDir）"
  },

  "gdb": {
    "path": "/usr/bin/gdb",
    "initCommands": ["初始化命令列表"]
  }
}
```

**字段说明**
- `build.workDir`: 编译产物目录，skill 调试时的工作目录，配置文件中的其他路径均相对于此
- `run.testcaseParam`: testngpp 框架的用例参数前缀，传给 shell 脚本
- `testRunner.format`: 测试框架类型，决定用例参数的传递方式
  - `testngpp`: 走 shell 脚本，用 `run.testcaseParam`
  - `gtest`: 直接传参，用 `testRunner.testcaseParam`
- `testRunner.testcaseParam`: gtest 框架的用例参数前缀，直接传给程序
- `env.*` 路径均相对于 workDir，无此字段时不设置环境变量

### 参数推导规则

当用户提供 `用例名` 和 `工程名` 时：

1. **加载配置文件**: 读取 `projects/{工程名}.json`
2. **确定 workDir**: 直接使用 `build.workDir`（已由用户预先计算好）
3. **拼接测试相关路径**（均相对于 workDir）:
   - `testRunner.binary`: 相对于 workDir 的路径
   - `testRunner.testSuite`: 相对于 workDir 的路径
   - `testRunner.listener`: 相对于 workDir 的路径
   - `env.LD_LIBRARY_PATH`: 相对于 workDir 的路径
4. **设置环境变量**（可选）: 若存在 `env.LD_LIBRARY_PATH`，执行 `set env LD_LIBRARY_PATH=...`
5. **执行初始化命令**: 逐条执行 `gdb.initCommands`
6. **编译命令**: 直接使用 `build.command`
7. **运行命令**: 根据 `testRunner.format` 区分处理

#### 用例参数传递规则

**testngpp 框架**:
- 用例参数传给 shell 脚本: `run.command` + `run.testcaseParam` + `用例名`
- 示例: `sh run_nFT.sh -s:run -f:testcase`

**gtest 框架**:
- 用例参数直接传给程序: `testRunner.testcaseParam` + `用例名`
- 示例: `--gtest_filter=Suite.Case`
- skill 内部用 `set args --gtest_filter=xxx` 传递

## 1. 运行程序
根据 testRunner.format 区分框架，使用run.command运行
testcase是指用户提供的`用例名`
**testngpp 框架**:
```python
testcase = "Suite/CaseName"
verify_cmd = f"{run.command} {run.testcaseParam}{testcase}"
result = subprocess.run(verify_cmd, shell=True, cwd=projectRoot)
```

**gtest 框架**:
```python
testcase = "TestSuite.TestCase"
verify_cmd = f"{workDir}/{testRunner.binary} {testRunner.testcaseParam}{testcase}"
result = subprocess.run(verify_cmd, shell=True, cwd=workDir)
```

查看运行结果：
- 若通过，则返回提示说程序完成，结束skill流程。
- 若报错，则
   1. 记录报错信息
   2. 开始调试流程



## 1. 准备MCP及创建MCP，GDB会话

**启动 MCP 服务（如果未运行）**
```bash
python3.11 ../../../gdb-mcp-py/server.py
```

服务默认监听 `http://localhost:9000`

**初始化 MCP 连接**
命令格式示意：
```bash
curl -N --http1.1 -D - -X POST http://localhost:9000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-d '{
    "jsonrpc":"2.0",
    "id":1,
    "method":"initialize",
    "params":{
        "protocolVersion":"2026-07-06",
        "capabilities":{},
        "clientInfo":{"name":"client","version":"1.0"}
    }
}'
```
提取响应 Header 中的 `mcp-session-id`

**调用 `start_session`**（从配置文件 build.workDir 读取）
```python
start_session(working_directory="{build.workDir}")
```
命令格式示意：
```bash
curl -N --http1.1 -X POST http://localhost:9000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":2,
    "method":"tools/call",
    "params":{
        "name":"start_session",
        "arguments":{"working_directory":"/path/to/project"}
    }
}'
```

## 3. 开始调试
调试期间所有调用gdb命令遵循以下格式示例：
```bash
curl -N --http1.1 -X POST http://localhost:9000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":3,
    "method":"tools/call",
    "params":{
        "name":"execute_command",
        "arguments":{
            "session_id":"<gdb-session-id>",
            "command":"file ./build/test_ut"
        }
    }
}'
```

1. **设置环境变量**（若配置中存在 env.LD_LIBRARY_PATH）
   ```python
   # env 路径相对于 workDir
   execute_command(session_id, "set env LD_LIBRARY_PATH={workDir}/../../3rdparty/unix/lib")
   ```

2. **执行 GDB 初始化命令**（从配置文件 gdb.initCommands 读取）
   ```python
   for cmd in gdb.initCommands:
       execute_command(session_id, cmd)
   ```

3. **加载测试运行器**（从 testRunner.binary 拼接，相对于 workDir）
   ```python
   execute_command(session_id, "file {workDir}/{testRunner.binary}")
   ```

4. **设置运行参数**（根据 testRunner.format 区分）

   **testngpp 框架**:
   ```python
   # 拼接 testngpp-runner 的参数
   test_args = [
       testRunner.testSuite,                    # "./testSuitRepo/libeFT_feature"
       f"-L{workDir}/{testRunner.listener}",   # listener 路径
       *testRunner.fixedArgs,                  # ["-ltestngppstdoutlistener", "-c", "-v"]
       f"-f:{testcase}"    # "-f:testcase"
   ]
   execute_command(session_id, f"set args {' '.join(test_args)}")
   ```

   **gtest 框架**:
   ```python
   # 直接传递 --gtest_filter 参数
   testcase_param = testRunner.testcaseParam or "--gtest_filter="
   execute_command(session_id, f"set args {testcase_param}TestSuite.TestCase")
   ```

5. **开始代码调试**

   - 首先根据前文运行的报错代码为指导进行调试，开始单步调试、查看变量、分析问题等。
   
   常用交互式GDB命令参考
   ```json
   "command":"file ./a.out"          # 加载可执行程序
   "command":"break main"            # 函数断点
   "command":"run arg1 arg2"         # 带参数启动程序
   "command":"info registers"        # 查看寄存器
   "command":"print global_var"      # 打印变量
   "command":"next"                  # 单步跳过
   "command":"step"                  # 单步进入
   "command":"bt"                    # 打印调用栈
   ```

   常用MI2机器指令参考
   ```json
   "command":"-file-exec-and-symbols ./a.out"  # MI加载程序
   "command":"-break-insert main"              # MI设置断点
   "command":"-exec-run"                       # MI运行程序
   "command":"-exec-next"                      # MI单步跳过
   "command":"-stack-list-frames"              # MI获取调用栈结构化数据
   "command":"-data-list-register-values x"    # MI读取寄存器十六进制值
   ```

   常见崩溃场景快速定位
   | 崩溃现象 | 可能原因 | 排查方向 |
   |----------|----------|----------|
   | SIGSEGV 在 Pool 分配函数 | 内存权限问题 | 检查 `SetShareMemoryReadWrite` 调用 |
   | 多线程下随机崩溃 | 竞态条件 | 检查线程同步、锁的使用 |
   | 初始化后崩溃 | 初始化顺序问题 | 检查 `InitXxx` 调用顺序 |
   | 特定用例崩溃 | 测试环境未正确设置 | 对比其他正常用例的差异 |

   **场景索引**
   - 如果前文调试无法找到原因，可以根据用户提示或自主判断调试任务类型，进入对应 doc文件读取内容获取具体 GDB 命令指导：
   | 任务类型 | doc 文件 |
   |----------|-----------|
   | 追踪变量来源、验证断点、定位 Bug | [docs/gdb-general-trace.md](./docs/gdb-general-trace.md) |
   | 分析 UT 失败原因，修复测试用例 | [docs/gdb-ut-fix.md](./docs/gdb-ut-fix.md) |
   | 验证 UT 执行路径与测试意图一致性 | [docs/gdb-ut-validate.md](./docs/gdb-ut-validate.md) |
   | 修复只读内存导致的 SIGSEGV 段错误 | [docs/gdb-readonly-memory-fix.md](./docs/gdb-readonly-memory-fix.md) |
   | CT 用例 SearchSpace 配置不匹配导致 OSI 调度失败 | [docs/gdb-ct-searchspace-fix.md](./docs/gdb-ct-searchspace-fix.md) |
   对应场景需要的参数需要根据用户需求或自主分析获得后使用MCP的execute_command工具进行gdb的参数添加。

## 4. 结束当前调试会话
   当查找到报错原因，退出调试，进入第5步进行代码修复。
   当调试操作超过50次还没有找到原因，则退出调试并向用户报告。
   ```python
   execute_command(session_id, "quit")
   close_session(session_id)
   ```
   命令示意
   ```bash
   curl -N --http1.1 -X POST http://localhost:9000/mcp \
   -H "Content-Type: application/json" \
   -H "Accept: application/json, text/event-stream" \
   -H "mcp-session-id: <mcp-session-id>" \
   -d '{
      "jsonrpc":"2.0",
      "id":4,
      "method":"tools/call",
      "params":{
         "name":"close_session",
         "arguments":{"session_id":"<gdb-session-id>"}
      }
   }'
   ```

## 5. 代码修复

   根据调试结果进行代码修复，修复完成重新编译
   ```python
   # 编译
   subprocess.run(build.command, shell=True, cwd=projectRoot)
   ```

   编译完成回到第1步重新运行,如果运行通过则给出一个调试报告。运行不通过则根据报错内容重新开始调试。

## 6. 保存经验（调试全部通过后执行）

**执行时机**
- 仅在所有调试循环完成、测试全部通过后，由用户主动触发将经验整理成文档保存到 `docs/` 目录
- 编译-调试循环阶段不触发此步骤

**保存条件**
- 必须得到用户明确回复后才能创建/修改文档
- 拒绝保存时，跳过此步骤

**文档编写规范**

docs 中的文档应聚焦于业务特定的知识：
- ✅ **应包含**：针对本项目的关键 GDB 命令、常用断点位置、问题排查方向、典型崩溃模式
- ❌ **不应包含**：MCP 初始化、curl 调用格式、GDB 基础命令说明、通用配置步骤

**文档结构示例**

```markdown
# {问题类型} 排查指南

## 典型场景
描述什么情况下适用本文档

## 关键断点
- `break function_name` - 原因

## 排查命令
- `print variable_name` - 查看什么
- `bt` - 调用栈特征

## 常见原因
1. xxx 导致 yyy
2. zzz 未正确初始化
```

**更新场景索引**
保存文档后，在 SKILL.md 的「选择场景」表格中补充新场景条目：

```markdown
| 任务类型 | doc 文件 |
|----------|-----------|
| {新场景描述} | [docs/xxx.md](./docs/xxx.md) |
```

# 其他补充内容

## 传统通用方式

当没有配置文件或需要自定义时：

**testngpp 框架**:
```python
execute_command(session_id, "set pagination off")
execute_command(session_id, "set breakpoint pending on")
execute_command(session_id, "set print pretty on")
execute_command(session_id, "file ./testngpp-runner")
execute_command(session_id, "set args ./testSuitRepo/libeFT_feature -L... -ltestngppstdoutlistener -c -v -f:{testcase}")
execute_command(session_id, "break function_name")
execute_command(session_id, "run")
```

**gtest 框架**:
```python
execute_command(session_id, "set pagination off")
execute_command(session_id, "set breakpoint pending on")
execute_command(session_id, "set print pretty on")
execute_command(session_id, "file ./uac_ut_feature")
execute_command(session_id, "set args --gtest_filter={TestSuite}.{TestCase}")
execute_command(session_id, "break function_name")
execute_command(session_id, "run")
```

---
## 关键注意事项

1. **终端会话限制**  
   `mcp-session-id` 绑定当前curl终端连接，新开终端需要重新执行 `initialize`，旧GDB会话会失效丢失。  
2. **curl必带参数**  
   - `-N`：关闭输出缓冲，适配SSE流式响应，否则请求卡死无返回  
   - `--http1.1`：强制HTTP1.1，避免http2流式兼容异常  
3. **请求头不可缺失**  
   - `Content-Type: application/json`  
   - `Accept: application/json, text/event-stream`（缺失会报406 Not Acceptable）  
   - `mcp-session-id: xxx`（缺失会话关联，工具调用异常）  
4. **GDB MI协议核心特性**  
   - 会话持久：多次调用 `execute_command` 共享同一个GDB进程，断点、程序运行状态全部保留  
   - 无调用次数限制：单GDB会话可循环执行上千条命令，无需重复创建会话  
   - 混合兼容：MI机器指令与人用交互式命令可任意穿插使用  
5. **日志排查**  
   服务端运行日志路径：`/tmp/gdb_mcp_server.log`，可查看GDB进程启动、PID、崩溃信息。  
6. **错误码说明**  
   - 404：接口路径错误，必须使用 `/mcp`  
   - 406：Accept头缺少 `text/event-stream`  
   - 会话不存在：`mcp-session-id` 或GDB session_id填写错误、连接已失效  

---

## 完整执行成功标识

1. HTTP返回 `200 OK`，`content-type: text/event-stream`  
2. 输出包含 `event: message` 行  
3. JSON返回 `isError:false`  
4. `output` 字段末尾带有 `(gdb)` 提示符，代表GDB命令执行完毕  
5. MI指令返回结构化 `^done` / `^running` / `^error` 标准MI前缀输出  

