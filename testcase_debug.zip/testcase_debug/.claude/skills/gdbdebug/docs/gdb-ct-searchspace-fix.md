# CT 用例 SearchSpace 配置不匹配问题排查

## 典型场景

SIB1/Paging 等 OSI (Other System Information) 调度测试用例失败，报错信息：
```
expected (dlSchdInd.curCellBwpIdx == X), found ((unsigned char)0/0 != (int)0xX/X)
```

其中 `dlSchdInd.scheType` 也为 0（初始值），表示调度未成功。

## 关键断点

- `test_cce_alloc_test.hpp:142` - SIB1 调度验证点（`curCellBwpIdx` 断言）
- `test_cce_alloc_test.hpp:217` - Paging 调度验证点

## 排查命令

```gdb
# 查看 SIB1 请求参数
print sib1Req1.cellBwpIdx    # 请求的 BWP 索引
print sib1Req1.searchSpaceId # 请求的 SearchSpace ID

# 查看调度结果
print dlSchdInd.curCellBwpIdx  # 期望值应为 sib1Req1.cellBwpIdx
print dlSchdInd.scheType       # 期望值应为 SIB1_SCHED 或 PAGING_SCHED
print dlSchdInd.dci.searchSpaceID  # 期望值应为配置的 searchSpaceId
```

## 常见原因

### 1. SearchSpace 配置不匹配

**现象**：
- 测试用例设置了 `searchSpaceId = 150`
- 场景函数 `SetRedcapMultiBwpSearchSpaceReuse` 只配置了 `searchSpaceId = 15`
- 调度失败，`curCellBwpIdx` 保留初始值 0

**排查方向**：
1. 检查测试用例中 `sib1Req1.searchSpaceId` 或 `pagingSchdReq.searchSpaceId` 的值
2. 对比场景函数中对应 BWP 的 searchSpace 配置
3. 确认 request 中的 searchSpaceId 与场景配置的 searchSpaceId 一致

**修复方法**：
将测试用例中的 `searchSpaceId` 改为与场景配置一致的值。

### 2. BWP 配置缺失

**现象**：
- 测试用例请求 BWP 4/5/6/7
- 场景函数未配置对应 BWP 的 searchSpace

**排查方向**：
检查 `SetRedcapMultiBwpSearchSpaceReuse` 函数中是否包含目标 BWP 的 `SetMccCellDlPdcchConfigCommonSearchSpace` 调用。

### 3. cellBwpIdx 与实际 BWP 索引不一致

**现象**：
- `sib1Req1.cellBwpIdx = 4` 请求 BWP4 调度
- 但实际场景中 BWP4 的 searchSpace 可能配置在其他位置

**排查方向**：
1. 确认 `SetDualBwpCellCfg` 中 BWP 索引与 searchSpace 配置的对应关系
2. 检查 BWP 配置顺序是否正确

## 经验总结

| 场景函数 | 常见问题 |
|----------|----------|
| `SetRedcapMultiBwpSearchSpaceReuse` | searchSpaceId 只配了 15，测试用例不应使用 150 |
| 其他多 BWP 场景函数 | 确认每个目标 BWP 都有完整的 searchSpace 配置 |

调试时优先检查 `sib1Req1.searchSpaceId` 与场景配置的一致性，这是最常见的失败原因。