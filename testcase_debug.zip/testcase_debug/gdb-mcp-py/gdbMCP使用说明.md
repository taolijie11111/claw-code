# gdbMCP使用说明

1. 检查gdbMCP注册，路径`/home/00359039/.claude/settings.json`里面有无注册，没有提示要注册，有的话开始调试  
2. 检查`http://localhost:8000/mcp`有无进行链接，如果无法连接需要运行命令  
   ```bash
   python3.11 /home/00359039/Desktop/gdb-claw/gdb-mcp-py/server.py
   ```
   进行启动。失败重试直到链接上。

---

## 一、环境前置说明

1. **服务端**：`server.py` 启动方式为 `mcp.run(transport="streamable-http")`，默认监听 `http://localhost:8000`  
2. **两层会话概念**  
   - **MCP-Session-ID**：HTTP流式长连接会话，`initialize` 握手时从响应Header获取，全局请求必须携带  
   - **GDB Session ID**：单个常驻GDB MI2调试子进程会话，`start_session` 创建后得到，用于持续下发调试指令  
3. **依赖**  
   - Python3.11 + fastmcp  
   - gdb（系统预装，支持MI2交互模式）  
   - curl  

---

## 二、完整调用流程总览

1. 初始化握手 `initialize` → 获取 `mcp-session-id`  
2. 创建GDB调试会话 `start_session` → 获取 `gdb session_id`（启动 `gdb --interpreter=mi2`）  
3. 循环执行任意GDB指令 `execute_command`  
   - 底层基于 **GDB MI2 Machine Interface 机器交互协议**  
   - 支持标准GDB交互式命令 + 全部MI机器指令  
   - 单一会话内执行次数、连续下发命令数量无上限，会话生命周期内可无限次调用  
4. 销毁GDB会话 `close_session` → 关闭GDB子进程释放资源  

---

## 三、分步curl命令示例（可直接复制执行）

### 1. 初始化MCP连接（获取Mcp-Session-Id）

```bash
curl -N --http1.1 -D - -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-d '{
    "jsonrpc":"2.0",
    "id":1,
    "method":"initialize",
    "params":{
        "protocolVersion":"2024-11-05",
        "capabilities":{},
        "clientInfo":{"name":"curl","version":"1.0"}
    }
}'
```

#### 关键输出提取
响应Header中会出现：
```
mcp-session-id: fda8ef13ca014b609ac0a531f17361d6
```
后续所有请求都必须带上该Header。

---

### 2. 创建GDB调试会话（指定工作目录）

替换 `mcp-session-id` 为上一步拿到的值，`working_directory` 修改为你的项目绝对路径：

```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: fda8ef13ca014b609ac0a531f17361d6" \
-d '{
    "jsonrpc":"2.0",
    "id":2,
    "method":"tools/call",
    "params":{
        "name":"start_session",
        "arguments":{"working_directory":"/home/00359039/Desktop/gdb-claw"}
    }
}'
```

#### 返回结果示例
```json
{"jsonrpc":"2.0","id":2,"result":{"content":[{"type":"text","text":"{\n  \"session_id\": \"fc89f075-44bc-41c9-a26a-5c431a79f013\",\n  \"status\": \"可用\",\n  \"working_directory\": \"/home/00359039/Desktop/gdb-claw\"\n}"}],"isError":false}}
```
提取 `session_id: fc89f075-44bc-41c9-a26a-5c431a79f013` 作为GDB会话标识。

---

### 3. 执行GDB调试命令（核心：支持MI2协议+原生交互式命令）

#### 协议说明
服务端GDB子进程启动参数 `gdb --interpreter=mi2`，指令层完全兼容两套语法：
1. **普通交互式GDB命令**（人可读，日常调试使用）
2. **MI2机器接口命令**（`-` 开头，结构化输出，自动化调试推荐）

同一GDB会话内，可**无限制、无限次**交替下发两种类型指令，会话不会重置、GDB调试状态持续保留。

#### 示例1：普通交互式命令（查看GDB版本）
```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: fda8ef13ca014b609ac0a531f17361d6" \
-d '{
    "jsonrpc":"2.0",
    "id":3,
    "method":"tools/call",
    "params":{
        "name":"execute_command",
        "arguments":{
            "session_id":"fc89f075-44bc-41c9-a26a-5c431a79f013",
            "command":"show version"
        }
    }
}'
```

#### 示例2：标准MI2机器指令（加载可执行文件）
```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: fda8ef13ca014b609ac0a531f17361d6" \
-d '{
    "jsonrpc":"2.0",
    "id":4,
    "method":"tools/call",
    "params":{
        "name":"execute_command",
        "arguments":{
            "session_id":"fc89f075-44bc-41c9-a26a-5c431a79f013",
            "command":"-file-exec-and-symbols ./a.out"
        }
    }
}'
```

---

### 3.1 设置程序运行参数（替代 `gdb --args`）

在使用 gdbMCP 时，GDB 会话通过 `start_session` 启动后，**通常需要先加载可执行文件，再设置运行参数**（相当于传统 `gdb --args` 的功能），最后才执行 `run` 启动程序。  
典型的调试第一步是加载可执行文件并设置参数，例如要对测试程序 `uac_ut_feature` 运行指定的 Google Test 用例：

#### ① 加载可执行文件（普通交互式命令）
```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <your-mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":<unique-id>,
    "method":"tools/call",
    "params":{
        "name":"execute_command",
        "arguments":{
            "session_id":"<your-gdb-session-id>",
            "command":"file ./uac_ut_feature"
        }
    }
}'
```

#### ② 设置运行参数（关键步骤：相当于 `gdb --args` 的参数部分）
```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <your-mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":<unique-id>,
    "method":"tools/call",
    "params":{
        "name":"execute_command",
        "arguments":{
            "session_id":"<your-gdb-session-id>",
            "command":"set args --gtest_filter=SendUeSyncCmpIndTest.Test_SendUeSyncCmpInd_ValidInput_Success"
        }
    }
}'
```

#### 参数说明
- **`file ./uac_ut_feature`**：加载当前目录下的可执行文件 `uac_ut_feature`（若路径不同请替换为绝对路径或相对路径）。  
- **`set args --gtest_filter=SendUeSyncCmpIndTest.Test_SendUeSyncCmpInd_ValidInput_Success`**：  
  设置程序运行时的命令行参数。这里指定了 Google Test 的过滤条件 `--gtest_filter`，表示只执行测试用例 `SendUeSyncCmpIndTest.Test_SendUeSyncCmpInd_ValidInput_Success`。  
  该参数的意义是：**限定仅运行这个特定的测试用例**，用于缩小调试范围，避免执行全部测试。

> ⚠️ **注意**  
> - 这是 GDB 启动后的**第一步必要设置**（加载文件和参数），之后可以继续执行断点、`run` 等命令。  
> - 如果程序不需要额外参数，可以省略 `set args` 步骤。  
> - 该命令与 GDB 原生 `gdb --args ./uac_ut_feature --gtest_filter=...` 效果等价，但因 MCP 会话已存在，需分两步完成。

#### 完整后续步骤（示例）
设置完参数后，可继续添加断点并运行：
```bash
# 3. 设置断点（例如在 main 函数）
curl ... -d '{"... "command":"break main"}'

# 4. 运行程序
curl ... -d '{"... "command":"run"}'
```
所有命令在同一 GDB 会话内共享状态，断点、参数等均会保留。

---

#### 常用交互式GDB命令参考
```json
"command":"file ./a.out"          # 加载可执行程序
"command":"break main"            # 函数断点
"command":"run arg1 arg2"         # 带参数启动程序
"command":"info registers"        # 查看寄存器
"command":"print global_var"      # 打印变量
"command":"next"                  # 单步跳过
"command":"step"                  # 单步进入
"command":"bt"                    # 打印调用栈
```

#### 常用MI2机器指令参考
```json
"command":"-file-exec-and-symbols ./a.out"  # MI加载程序
"command":"-break-insert main"              # MI设置断点
"command":"-exec-run"                       # MI运行程序
"command":"-exec-next"                      # MI单步跳过
"command":"-stack-list-frames"              # MI获取调用栈结构化数据
"command":"-data-list-register-values x"    # MI读取寄存器十六进制值
```

---

### 4. 关闭GDB调试会话（释放gdb子进程）

```bash
curl -N --http1.1 -X POST http://localhost:8000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: fda8ef13ca014b609ac0a531f17361d6" \
-d '{
    "jsonrpc":"2.0",
    "id":5,
    "method":"tools/call",
    "params":{
        "name":"close_session",
        "arguments":{"session_id":"fc89f075-44bc-41c9-a26a-5c431a79f013"}
    }
}'
```

---

## 四、关键注意事项

1. **终端会话限制**  
   `mcp-session-id` 绑定当前curl终端连接，新开终端需要重新执行 `initialize`，旧GDB会话会失效丢失。  
2. **curl必带参数**  
   - `-N`：关闭输出缓冲，适配SSE流式响应，否则请求卡死无返回  
   - `--http1.1`：强制HTTP1.1，避免http2流式兼容异常  
3. **请求头不可缺失**  
   - `Content-Type: application/json`  
   - `Accept: application/json, text/event-stream`（缺失会报406 Not Acceptable）  
   - `mcp-session-id: xxx`（缺失会话关联，工具调用异常）  
4. **GDB MI协议核心特性**  
   - 会话持久：多次调用 `execute_command` 共享同一个GDB进程，断点、程序运行状态全部保留  
   - 无调用次数限制：单GDB会话可循环执行上千条命令，无需重复创建会话  
   - 混合兼容：MI机器指令与人用交互式命令可任意穿插使用  
5. **日志排查**  
   服务端运行日志路径：`/tmp/gdb_mcp_server.log`，可查看GDB进程启动、PID、崩溃信息。  
6. **错误码说明**  
   - 404：接口路径错误，必须使用 `/mcp`  
   - 406：Accept头缺少 `text/event-stream`  
   - 会话不存在：`mcp-session-id` 或GDB session_id填写错误、连接已失效  

---

## 五、完整执行成功标识

1. HTTP返回 `200 OK`，`content-type: text/event-stream`  
2. 输出包含 `event: message` 行  
3. JSON返回 `isError:false`  
4. `output` 字段末尾带有 `(gdb)` 提示符，代表GDB命令执行完毕  
5. MI指令返回结构化 `^done` / `^running` / `^error` 标准MI前缀输出  

---

## 结束输出调试报告
在gdb会话结束之后，根据调试过程和日志，生成一个调试报告和总体流程。