---
name: gdbdebug
description: 本文档是 GDB 调试任务的入口文件，定义调试流程和场景指导。
---

## 工程配置

每个项目在 `projects/` 目录下维护一个 JSON 配置文件：

```
.claude/skills/gdbdebug/projects/
├── aiot_eFT.json
└── other_project.json
```

### 配置文件结构

```json
{
  "name": "工程名称",
  "description": "工程描述",

  "build": {
    "command": "编译命令",
    "outputDir": "编译产物目录（相对于项目根）",
    "ftVersionMap": {
      "3_0": "v3",
      "3_c": "3c",
      "2_0": "v2",
      "v2": "v2",
      "es": "es",
      "3_e": "3e"
    },
    "dirNamePattern": "{productType}_{ftVersion}{cpt}Sln",
    "cptParam": "-s:"  // 可选，指定从哪个参数提取 cpt 值，默认从 -s: 参数提取
  },

  "run": {
    "command": "运行命令（用 {testcase} 占位符表示用例名）",
    "testcaseParam": "用例参数标记（如 -f::）"
  },

  "testRunner": {
    "binary": "测试运行器路径（相对于 workDir）",
    "testcaseFormat": "testngpp | gtest",
    "testSuite": "测试套件相对路径（testngpp 用，相对于 workDir）",
    "listenerPath": "监听器路径（testngpp 用，相对于 workDir）",
    "fixedArgs": ["固定参数列表（testngpp 用）"]
  },

  "env": {
    "LD_LIBRARY_PATH": "运行时库路径（相对于 workDir）"
  },

  "gdb": {
    "path": "/usr/bin/gdb",
    "useGdbArgs": true,
    "initCommands": ["初始化命令列表"]
  }
}
```

**字段说明**
- `build.outputDir`: 编译产物目录的父目录（不含 slnName），如 `aspa/eft/ft/build`
- `build.ftVersionMap`: 可选，ftVersion 转换映射（如 `3_e` -> `3e`）
- `build.dirNamePattern`: 可选，输出目录名模式，默认 `{productType}_{ftVersion}{cpt}Sln`
- `build.cptParam`: 可选，指定从哪个编译参数提取 cpt 值，默认从 `-s:` 参数提取（如 `-ct:` 用于 spaUt）
- `testRunner.*` 路径均相对于 workDir（`build.outputDir/slnName`）
- `env.*` 路径均相对于 workDir
- `env` 可选，无此字段时不设置环境变量
- `gdb.useGdbArgs` 可选，默认 false

### 参数推导规则

当用户提供 `用例名` 和 `工程名` 时：

1. **加载配置文件**: 读取 `projects/{工程名}.json`
2. **解析编译命令并计算 workDir**:
   - 从 `build.command` 提取参数（如 `-v:3_e -p:aiot -s:cc`）
   - 根据编译脚本逻辑计算输出目录名
   - workDir = `{build.outputDir}/{slnName}`
3. **拼接测试相关路径**（均相对于 workDir）:
   - `testRunner.binary`: 相对于 workDir 的路径
   - `testRunner.testSuite`: 相对于 workDir 的路径
   - `testRunner.listenerPath`: 相对于 workDir 的路径
   - `env.LD_LIBRARY_PATH`: 相对于 workDir 的路径
4. **设置环境变量**（可选）: 若存在 `env.LD_LIBRARY_PATH`，执行 `set env LD_LIBRARY_PATH=...`
5. **执行初始化命令**: 逐条执行 `gdb.initCommands`
6. **编译命令**: 直接使用 `build.command`
7. **运行命令**: 替换 `{testcase}` 占位符为实际用例名后执行 `run.command`

#### 动态路径解析示例

以 aiot_eFT 项目的 `run_nFT.sh` 为例：

```python
# 1. 从 build.command 解析参数
# command: "cd aspa/eft/ft && sh run_nFT.sh -v:3_e -p:aiot -s:cc"
# 提取: productType=aiot, ftVersion=3_e, cpt=spa

# 2. 根据编译脚本逻辑转换 ftVersion
ft_version_map = {
    "3_0": "v3",
    "3_c": "3c",
    "2_0": "v2",
    "v2": "v2",
    "es": "es",
    "3_e": "3e"
}
# 3_e -> 3e

# 3. 计算目录名: {productType}_{ftVersion}{cpt}Sln
# aiot + _ + 3e + spa + Ssln = "aiot_3espaSln"

# 4. workDir = "aspa/eft/ft/build/aiot_3espaSln"

# 5. 其他路径相对于 workDir:
# binary: "../../3rdparty/x86-gcc-6/testngpp/bin/testngpp-runner"
# testSuite: "./testSuitRepo/libeFT_feature"
# listenerPath: "../../3rdparty/x86-gcc-6/testngpp/testngpp/listener"
# LD_LIBRARY_PATH: "../../3rdparty/x86-gcc-6/testngpp/lib"
```

### 用户输入简化

用户只需提供：
- 工程名（自动匹配配置文件）
- 用例名（根据框架类型自动组装参数）

其他所有路径、命令、环境变量均从配置文件自动推导。

---

## 调试流程

### 0. 加载工程配置

**列出可用工程**
```bash
ls .claude/skills/gdbdebug/projects/
```

**读取工程配置**
读取 `projects/{工程名}.json` 获取调试所需的路径和命令模板。

### 1. 准备

**启动 MCP 服务（如果未运行）**
```bash
python3.11 /home/00359039/Desktop/gdb-claw/gdb-mcp-py/server.py
```

服务默认监听 `http://localhost:9000`

### 2. 创建会话

**调用 `start_session`**

```
工具: start_session
参数:
  working_directory: "/path/to/project"  # 项目根目录绝对路径
```

**返回**
```json
{
  "session_id": "fc89f075-44bc-41c9-a26a-5c431a79f013",
  "status": "可用"
}
```

### 3. 选择场景
根据用户提示或自主判断调试任务类型，进入对应 doc文件读取内容获取具体 GDB 命令指导：
| 任务类型 | doc 文件 |
|----------|-----------|
| 追踪变量来源、验证断点、定位 Bug | [docs/gdb-general-trace.md](./docs/gdb-general-trace.md) |
| 分析 UT 失败原因，修复测试用例 | [docs/gdb-ut-fix.md](./docs/gdb-ut-fix.md) |
| 验证 UT 执行路径与测试意图一致性 | [docs/gdb-ut-validate.md](./docs/gdb-ut-validate.md) |
| 修复只读内存导致的 SIGSEGV 段错误 | [docs/gdb-readonly-memory-fix.md](./docs/gdb-readonly-memory-fix.md) |
对应场景需要的参数需要根据用户需求或自主分析获得后使用MCP的execute_command工具进行gdb的参数添加。

#### 常见崩溃场景快速定位

| 崩溃现象 | 可能原因 | 排查方向 |
|----------|----------|----------|
| SIGSEGV 在 Pool 分配函数 | 内存权限问题 | 检查 `SetShareMemoryReadWrite` 调用 |
| 多线程下随机崩溃 | 竞态条件 | 检查线程同步、锁的使用 |
| 初始化后崩溃 | 初始化顺序问题 | 检查 `InitXxx` 调用顺序 |
| 特定用例崩溃 | 测试环境未正确设置 | 对比其他正常用例的差异 |

#### 常用交互式GDB命令参考
```json
"command":"file ./a.out"          # 加载可执行程序
"command":"break main"            # 函数断点
"command":"run arg1 arg2"         # 带参数启动程序
"command":"info registers"        # 查看寄存器
"command":"print global_var"      # 打印变量
"command":"next"                  # 单步跳过
"command":"step"                  # 单步进入
"command":"bt"                    # 打印调用栈
```

#### 常用MI2机器指令参考
```json
"command":"-file-exec-and-symbols ./a.out"  # MI加载程序
"command":"-break-insert main"              # MI设置断点
"command":"-exec-run"                       # MI运行程序
"command":"-exec-next"                      # MI单步跳过
"command":"-stack-list-frames"              # MI获取调用栈结构化数据
"command":"-data-list-register-values x"    # MI读取寄存器十六进制值
```


### 4. 结束会话

**调用 `close_session`**

```
工具: close_session
参数:
  session_id: "fc89f075-44bc-41c9-a26a-5c431a79f013"
```

### 5. 保存调试经验（调试全部通过后执行）

**执行时机**
- 仅在所有调试循环完成、测试全部通过后询问
- 编译-调试循环阶段不触发此步骤

**询问用户**
> 本次调试已完成，是否将经验整理成文档保存到 `docs/` 目录？

**保存条件**
- 必须得到用户明确回复后才能创建/修改文档
- 拒绝保存时，跳过此步骤

**文档编写规范**

docs 中的文档应聚焦于业务特定的知识：
- ✅ **应包含**：针对本项目的关键 GDB 命令、常用断点位置、问题排查方向、典型崩溃模式
- ❌ **不应包含**：MCP 初始化、curl 调用格式、GDB 基础命令说明、通用配置步骤

**文档结构示例**

```markdown
# {问题类型} 排查指南

## 典型场景
描述什么情况下适用本文档

## 关键断点
- `break function_name` - 原因

## 排查命令
- `print variable_name` - 查看什么
- `bt` - 调用栈特征

## 常见原因
1. xxx 导致 yyy
2. zzz 未正确初始化
```

**更新场景索引**
保存文档后，在 SKILL.md 的「选择场景」表格中补充新场景条目：

```markdown
| 任务类型 | doc 文件 |
|----------|-----------|
| {新场景描述} | [docs/xxx.md](./docs/xxx.md) |
```

---

## 完整调用示例
所有对GDB的调试调用都应该遵守这些格式

### 初始化 MCP 连接

```bash
curl -N --http1.1 -D - -X POST http://localhost:9000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-d '{
    "jsonrpc":"2.0",
    "id":1,
    "method":"initialize",
    "params":{
        "protocolVersion":"2026-07-06",
        "capabilities":{},
        "clientInfo":{"name":"client","version":"1.0"}
    }
}'
```

**提取响应 Header 中的 `mcp-session-id`**

### 创建 GDB 会话

```bash
curl -N --http1.1 -X POST http://localhost:9000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":2,
    "method":"tools/call",
    "params":{
        "name":"start_session",
        "arguments":{"working_directory":"/path/to/project"}
    }
}'
```

### 执行 GDB 命令

```bash
curl -N --http1.1 -X POST http://localhost:9000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":3,
    "method":"tools/call",
    "params":{
        "name":"execute_command",
        "arguments":{
            "session_id":"<gdb-session-id>",
            "command":"file ./build/test_ut"
        }
    }
}'
```

### 关闭会话

```bash
curl -N --http1.1 -X POST http://localhost:9000/mcp \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-H "mcp-session-id: <mcp-session-id>" \
-d '{
    "jsonrpc":"2.0",
    "id":4,
    "method":"tools/call",
    "params":{
        "name":"close_session",
        "arguments":{"session_id":"<gdb-session-id>"}
    }
}'
```

---

## 标准调试流程

### 基于配置文件的调试（推荐）

1. **加载工程配置**
   ```python
   # 读取 projects/{工程名}.json
   # 根据 testcaseFormat 判断框架类型
   ```

2. **创建 GDB 会话**
   ```python
   start_session(working_directory="/path/to/project")
   ```

3. **设置环境变量**（若配置中存在 env.LD_LIBRARY_PATH）
   ```python
   execute_command(session_id, "set env LD_LIBRARY_PATH=...")
   ```

4. **执行 GDB 初始化命令**（从配置文件 gdb.initCommands 读取）
   ```python
   execute_command(session_id, "set pagination off")
   execute_command(session_id, "set breakpoint pending on")
   execute_command(session_id, "set print pretty on")
   ```

5. **加载测试运行器**（从 testRunner.binary 拼接）
   ```python
   execute_command(session_id, "file {projectRoot}/{testRunner.binary}")
   ```

6. **设置运行参数**（根据 testcaseFormat 区分）

   **testngpp 框架**:
   ```python
   test_args = [
       "./testSuitRepo/libeFT_feature",
       "-L./aspa/eft/3rdparty/x86-gcc-6/testngpp/testngpp/listener",
       "-ltestngppstdoutlistener",
       "-c", "-v",
       "-f:RAN5625276_construct_map_sender_test"
   ]
   execute_command(session_id, f"set args {' '.join(test_args)}")
   ```

   **gtest 框架**:
   ```python
   execute_command(session_id, "set args --gtest_filter=SendUeSyncCmpIndTest.Test_SendUeSyncCmpInd_ValidInput_Success")
   ```

7. **设置断点并运行**
   ```python
   execute_command(session_id, "break some_function")
   execute_command(session_id, "run")
   ```

8. **调试过程中**
   - 单步调试、查看变量、分析问题
   - 根据需要重复步骤 4-7（设置新断点、重新运行等）

9. **结束当前调试会话**
   ```python
   execute_command(session_id, "quit")
   close_session(session_id)
   ```

10. **修改代码后重新编译**
    ```python
    # 执行配置文件中的 build.command
    subprocess.run(build.command, shell=True, cwd=projectRoot)
    ```

11. **重新运行测试验证**
    ```python
    # 替换 run.command 中的 {testcase} 为实际用例名后执行
    cmd = run.command.replace("{testcase}", testcase_name)
    subprocess.run(cmd, shell=True, cwd=projectRoot)
    ```

12. **检查测试结果**
    - 若测试通过 → 调试完成
    - 若测试未通过 → 返回步骤 1，重新启动调试会话

### 传统通用方式

当没有配置文件或需要自定义时：

**testngpp 框架**:
```python
execute_command(session_id, "set pagination off")
execute_command(session_id, "set breakpoint pending on")
execute_command(session_id, "set print pretty on")
execute_command(session_id, "file ./testngpp-runner")
execute_command(session_id, "set args ./testSuitRepo/libeFT_feature -L... -ltestngppstdoutlistener -c -v -f:{testcase}")
execute_command(session_id, "break function_name")
execute_command(session_id, "run")
```

**gtest 框架**:
```python
execute_command(session_id, "set pagination off")
execute_command(session_id, "set breakpoint pending on")
execute_command(session_id, "set print pretty on")
execute_command(session_id, "file ./uac_ut_feature")
execute_command(session_id, "set args --gtest_filter={TestCase}.{TestName}")
execute_command(session_id, "break function_name")
execute_command(session_id, "run")
```

---
## 关键注意事项

1. **终端会话限制**  
   `mcp-session-id` 绑定当前curl终端连接，新开终端需要重新执行 `initialize`，旧GDB会话会失效丢失。  
2. **curl必带参数**  
   - `-N`：关闭输出缓冲，适配SSE流式响应，否则请求卡死无返回  
   - `--http1.1`：强制HTTP1.1，避免http2流式兼容异常  
3. **请求头不可缺失**  
   - `Content-Type: application/json`  
   - `Accept: application/json, text/event-stream`（缺失会报406 Not Acceptable）  
   - `mcp-session-id: xxx`（缺失会话关联，工具调用异常）  
4. **GDB MI协议核心特性**  
   - 会话持久：多次调用 `execute_command` 共享同一个GDB进程，断点、程序运行状态全部保留  
   - 无调用次数限制：单GDB会话可循环执行上千条命令，无需重复创建会话  
   - 混合兼容：MI机器指令与人用交互式命令可任意穿插使用  
5. **日志排查**  
   服务端运行日志路径：`/tmp/gdb_mcp_server.log`，可查看GDB进程启动、PID、崩溃信息。  
6. **错误码说明**  
   - 404：接口路径错误，必须使用 `/mcp`  
   - 406：Accept头缺少 `text/event-stream`  
   - 会话不存在：`mcp-session-id` 或GDB session_id填写错误、连接已失效  

---

## 完整执行成功标识

1. HTTP返回 `200 OK`，`content-type: text/event-stream`  
2. 输出包含 `event: message` 行  
3. JSON返回 `isError:false`  
4. `output` 字段末尾带有 `(gdb)` 提示符，代表GDB命令执行完毕  
5. MI指令返回结构化 `^done` / `^running` / `^error` 标准MI前缀输出  

