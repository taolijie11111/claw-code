# 通用代码追踪场景

> 本文档覆盖通用 GDB 调试任务：变量追踪、断点验证、Bug 定位。
> 详细流程请参考总入口 [SKILL.md](../SKILL.md)。

---

## 适用场景

- 追踪某个变量的来源（数据流分析）
- 验证代码能否执行到某个位置
- 定位程序崩溃原因
- 分析函数调用链

---

## 输入参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `target` | 可执行文件路径 | `./build/app` |
| `working_directory` | 项目根目录 | `/home/user/project` |
| `task` | 调试任务描述 | "追踪 `data->id` 的来源" |
| `initial_breakpoint` | 初始断点位置 | `main.c:100` 或 `process_data` |

---

## 变量追踪流程

### 模式 A: 从已知位置向上追溯

```
1. 在目标行设断点
   execute_command(session_id, "break file.c:120")

2. 运行到断点
   execute_command(session_id, "run")

3. 观察变量值
   execute_command(session_id, "print variable_name")

4. 查看调用栈，找到调用者
   execute_command(session_id, "bt")

5. 切换到调用者栈帧
   execute_command(session_id, "frame 1")

6. 查看函数参数和局部变量
   execute_command(session_id, "info args")
   execute_command(session_id, "info locals")

7. 重复直到找到源头
```

### 模式 B: 使用 watch 监视变量变化

```
1. 设置监视点
   execute_command(session_id, "watch global_var")

2. 继续运行直到变量改变
   execute_command(session_id, "continue")

3. 观察触发时的上下文
   execute_command(session_id, "bt")
   execute_command(session_id, "print global_var")
```

### 模式 C: 条件断点

```
1. 设置条件断点
   execute_command(session_id, "break file.c:123 if var == specific_value")

2. 运行
   execute_command(session_id, "run")
```

---

## 命令决策原则

### 优先级排序

1. **信息获取优先** — `bt`、`info registers`、`print` 优先于控制流命令
2. **最小干扰** — 用最少的命令获取足够信息
3. **批量执行** — 同一断点处可一次执行多个观察命令
4. **条件断点** — 复杂场景使用条件断点减少停顿次数

### 典型命令序列

| 场景 | 命令序列 |
|------|---------|
| 追踪变量来源 | `break` → `run` → `print var` → `bt` → `frame` → 向上追溯 |
| 栈回溯分析 | `bt` → `frame N` → `info args` → `info locals` |
| 崩溃分析 | `bt` → `frame N` → `print` 关键变量 |

---

## 安全边界

- **禁止修改内存或变量值**: `set var x = 10`
- **禁止执行 shell 命令**: `shell rm -rf /`
- **禁止加载工作目录外的二进制**: `file /bin/ls`
- **只允许操作 working_directory 内的文件**

---

## 输出要求

调试完成后输出：

```markdown
## 调试报告: [变量名/目标描述]

### 任务目标
[追踪/验证/定位目标]

### 调试过程
1. [关键步骤]
2. [关键步骤]

### 结论
- 变量来源: [文件:行号] 或 [未找到]
- 关键发现: [发现列表]
```
