# 只读内存段错误修复案例

> 本文档记录 SIGSEGV 段错误的调试过程和修复方法。
> 适用场景：AllocSender 等函数在写入共享内存时触发 SIGSEGV。

---

## 问题描述

### 测试用例信息

| 项目 | 值 |
|------|-----|
| 测试用例 | `RAN5625276_construct_map_sender_test` |
| 被测函数 | `AllocSender` |
| 崩溃信号 | **SIGSEGV (Segmentation fault)** |
| 崩溃地址 | `AllocSender+210` (sender_pool.c:102) |

### 崩溃时的调用栈

```
#0  AllocSender (size=512)  sender_pool.c:102  ← 崩溃点
#1  std::async lambda
#23 TaskManager::addTask lambda
#27 FT_OSS_SEM_Pend
#31 InterruptMomentLoop  ← 主线程等待信号量
```

### 崩溃代码

```c
// sender_pool.c:93-105
Sender* AllocSender(const WORD32 size)
{
    _SenderList* cThis = GetSenderPoolAddr();
    OneMemHead* head = (OneMemHead*)cThis->buf;
    const WORD32 alignSize = GET_ALIGN_SIZE_8(size);
    Sender* result = NULL;

    if (head->offset + alignSize >= SAFE_MULTI(...)) return NULL;
    result = (Sender*)(VOID*)(head->addr + head->offset);
    head->offset += alignSize;  // ← 崩溃发生在这里

    return result;
}
```

---

## 调试过程

### 1. 初始化 GDB 环境

遵循SKILL文件步骤

### 2. 加载程序和设置环境

```bash
# 初始化 GDB
execute_command(session_id, "set pagination off")
execute_command(session_id, "set breakpoint pending on")
execute_command(session_id, "set print pretty on")

# 加载程序
execute_command(session_id, "file /path/to/testngpp-runner")

# 设置环境变量
execute_command(session_id, "set environment LD_LIBRARY_PATH=/path/to/testngpp/lib")

# 设置运行参数
execute_command(session_id, "set args ./testSuitRepo/libeFT_feature ...")
```

### 3. 运行程序并分析崩溃

```bash
# 运行程序
execute_command(session_id, "run")

# 程序崩溃后，检查程序状态
execute_command(session_id, "info program")
# 输出: It stopped with signal SIGSEGV, Segmentation fault.

# 获取完整调用栈
execute_command(session_id, "bt")

# 查看崩溃位置的代码
execute_command(session_id, "frame 0")
execute_command(session_id, "list")

# 查看局部变量
execute_command(session_id, "info locals")
# 输出: cThis, head, alignSize 等

# 打印关键变量值
execute_command(session_id, "print *head")
execute_command(session_id, "print *cThis")
```

### 4. 关键发现

**崩溃时变量状态**：
```
head->addr = 0x7fff76800350  (数据区域起始地址)
head->size = 3181216         (总大小)
head->offset = 25152         (已分配偏移)
cThis->num = 7230            (Sender数量)
```

**线程信息**：
```
info threads
  Id   Target Id
* 2    Thread ...  AllocSender  ← 异步线程
  1    Thread ...  PendSemaphore  ← 主线程在等待
```

### 5. 深入分析：检查内存分配函数

设置断点跟踪初始化流程：

```bash
# 在关键函数设置断点
execute_command(session_id, "break InitFcsShareMemory")
execute_command(session_id, "break InitSenderPool")
execute_command(session_id, "break AllocReadOnlyShareMemory")

# 继续执行，观察断点命中顺序
execute_command(session_id, "continue")
```

### 6. 根本原因发现

检查 `AllocReadOnlyShareMemory` 的实现：

```c
// fcs_memory_readonly.c
VOID* AllocReadOnlyShareMemory(size_t size)
{
    FcsReadOnlyMemoryHead* readOnlyMemoryHead = GetFcsReadOnlyMemoryHead();
    // ... 分配只读内存区域
    return addr + ISOLATION_AREA_SIZE;
}
```

然后检查是否有内存权限修改函数：

```bash
grep -rn "SetShareMemoryReadWrite" /path/to/aspa/ --include="*.h"
# 找到: fcs_memory_readonly.h:21:VOID SetShareMemoryReadWrite();
```

查看实现：

```c
// fcs_memory_readonly.c
VOID SetShareMemoryReadWrite()
{
    FcsReadOnlyMemoryHead* readOnlyMemoryHead = GetFcsReadOnlyMemoryHead();
    g_mmuMmuModifyWrite = FCS_MmuModifyReadWrite(
        (size_t)(readOnlyMemoryHead->startAddr),
        readOnlyMemoryHead->memorySize
    );
}
```

### 7. 对比其他测试用例

检查其他正常运行的测试用例：

```bash
grep -n "SetShareMemoryReadWrite" test_ut_framework.hpp
# 输出:
# 211:  test.func.call(10, SetShareMemoryReadWrite);  // RAN5625276_refine_event_impl_test
# 290:  test.func.call(10, SetShareMemoryReadWrite);  // RAN5625276_construct_scq_fifo_to_point_test
# 336:  test.func.call(10, SetShareMemoryReadWrite);  // RAN5625276_construct_xc_to_point_test
```

**发现问题**：`RAN5625276_construct_map_sender_test` 没有调用 `SetShareMemoryReadWrite`！

---

## 问题链条分析

```
1. InitSenderPool() 调用 AllocReadOnlyShareMemory()
   → 分配只读内存区域

2. 后续 InitSenderPoolHead() 和 AllocSender() 需要写入内存
   → 但内存是只读的

3. 测试用例没有调用 SetShareMemoryReadWrite()
   → 内存仍为只读状态

4. 写入时触发 SIGSEGV
   → Segmentation fault
```

---

## 修复方案

### 修改内容

在测试用例开头添加内存权限设置：

```cpp
// test_ut_framework.hpp
TEST(RAN5625276_construct_map_sender_test)
{
    TestCase test("RAN5625276_construct_map_sender_test");
    test.cfg.setReaderId(1);
    ASSERT_TRUE(test.flow.readerSetup());
    ASSERT_TRUE(test.flow.readerRecfg());
    test.tti.run(10);

    // 将只读共享内存设置为可写（AllocSender 需要写入）
    test.func.call(10, SetShareMemoryReadWrite);
    test.tti.run();

    CommunicationBuilderImpl impl = {0};
    // ... 其余代码
}
```

### 编译验证

```bash
cd /path/to/aspa/eft/ft
sh run_nFT.sh -v:3_e -p:aiot -s:cc

# 运行测试验证
LD_LIBRARY_PATH=/path/to/testngpp/lib \
  /path/to/testngpp-runner \
  ./testSuitRepo/libeFT_feature \
  -L/path/to/listener -ltestngppstdoutlistener \
  -c -v -f:RAN5625276_construct_map_sender_test
```

### 修复后结果

```
===========================RESULT===========================
[    OK    ] 1 cases from 1 suites ran successfully.

(0s 710510us)
```

---

## 调试技巧总结

### 1. 识别只读内存问题的信号

| 现象 | 说明 |
|------|------|
| SIGSEGV 在写入时发生 | 可能是内存权限问题 |
| 写入地址看起来有效 | 排除了空指针问题 |
| 崩溃发生在 Pool 分配函数 | 可能涉及只读内存池 |

### 2. 查找只读内存相关函数

```bash
# 搜索内存权限修改函数
grep -rn "AllocReadOnlyShareMemory" path/to/code/ --include="*.c"
grep -rn "SetShareMemoryReadWrite" path/to/code/ --include="*.h"

# 搜索 mprotect 相关调用
grep -rn "mprotect\|PROT_WRITE" path/to/code/ --include="*.c"
```

### 3. 多线程调试要点

```bash
# 查看所有线程
execute_command(session_id, "info threads")

# 切换到特定线程
execute_command(session_id, "thread 2")

# 在所有线程上设置断点
execute_command(session_id, "break AllocSender")
```

### 4. 内存检查命令

```bash
# 查看内存内容
execute_command(session_id, "x/16x addr")

# 查看内存区域权限（需要 shell）
execute_command(session_id, "shell cat /proc/PID/maps | grep addr")
```

---

## 相关文件路径

| 文件 | 说明 |
|------|------|
| `sender_pool.c` | AllocSender 函数所在 |
| `fcs_memory_readonly.c` | 只读内存分配和权限管理 |
| `test_ut_framework.hpp` | 测试用例定义 |
| `fcs_memory_manager.c` | 内存初始化入口 |

---

## 通用检查清单

遇到类似 SIGSEGV 时，按以下顺序排查：

- [ ] 检查 `info program` 确认崩溃信号
- [ ] 执行 `bt` 获取完整调用栈
- [ ] 打印 `info locals` 查看局部变量
- [ ] 检查是否涉及多线程竞态
- [ ] 确认内存是否被声明为只读
- [ ] 检查是否有内存权限修改函数
- [ ] 对比其他正常用例的差异
- [ ] 确认初始化顺序是否正确