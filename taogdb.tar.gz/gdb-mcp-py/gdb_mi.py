import subprocess
import re
import json
import time
from typing import Dict, Any, Optional

class GdbMiSession:
    def __init__(self, working_dir: str = "."):
        self.working_dir = working_dir
        self.process: Optional[subprocess.Popen] = None
        self.token_counter = 0
        self.buffer = ""

    def start(self) -> None:
        """启动 GDB 子进程，使用 MI 模式"""
        self.process = subprocess.Popen(
            ["gdb", "-i=mi3", "--quiet", "--nx"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=self.working_dir,
            text=True,
            bufsize=1
        )
        # 等待 GDB 就绪（忽略初始消息）
        self._read_until_ready()

    def _read_until_ready(self, timeout: float = 5.0) -> None:
        """读取启动输出直到出现 =thread-group-added 或 ^done"""
        start = time.time()
        while time.time() - start < timeout:
            line = self._read_line()
            if not line:
                continue
            if line.startswith("=") or line.startswith("^done"):
                return
        raise TimeoutError("GDB 启动超时")

    def _read_line(self) -> str:
        """从 stdout 读取一行（阻塞）"""
        if not self.process:
            raise RuntimeError("GDB 进程未启动")
        return self.process.stdout.readline().strip()

    def send_command(self, command: str, timeout: float = 30.0) -> Dict[str, Any]:
        """
        发送 MI 命令并等待响应
        返回解析后的字典，包含 token, class, result, records
        """
        if not self.process:
            raise RuntimeError("GDB 进程未启动")

        self.token_counter += 1
        token = str(self.token_counter)
        full_cmd = f"{token}{command}\n"
        self.process.stdin.write(full_cmd)
        self.process.stdin.flush()

        response = {"token": token, "class": "", "result": {}, "records": []}
        start = time.time()

        while time.time() - start < timeout:
            line = self._read_line()
            if not line:
                continue

            # 解析输出记录 (~ 开头)
            if line.startswith("~"):
                response["records"].append({"type": "output", "content": line[1:]})
                continue
            # 解析异步记录 (*, +, =)
            if line.startswith(("*", "+", "=")):
                response["records"].append({"type": "notification", "content": line})
                # 如果是 *stopped 等，也可作为事件
                continue

            # 结果记录：token^class,payload
            if line.startswith(token):
                # 匹配 token^class,payload
                match = re.match(rf"^{token}\^(\w+)(?:,(.*))?$", line)
                if match:
                    response["class"] = match.group(1)
                    payload = match.group(2)
                    if payload:
                        response["result"] = self._parse_payload(payload)
                    # 如果是 done/running/error 等，认为命令完成
                    if response["class"] in ("done", "running", "connected", "error", "exit"):
                        break
        return response

    def _parse_payload(self, payload: str) -> Dict[str, Any]:
        """解析 MI 结果中的键值对（简化版）"""
        # 使用正则提取 name="value" 或 name={...} 或 name=[...]
        result = {}
        # 简单实现：用逗号分割，但要注意嵌套
        # 这里为了简洁，使用递归下降？但为了轻量，我们仅处理简单情况
        # 更健壮的做法是用 json 替换，但 MI 不是标准 json
        # 这里我们直接返回原始字符串，让调用者自己解析
        # 但我们可以做基本解析：提取 name=value 对
        # 为简化，这里返回原始字符串
        return {"raw": payload}  # 调用者可以自行解析

    def close(self) -> None:
        """终止 GDB 进程"""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None