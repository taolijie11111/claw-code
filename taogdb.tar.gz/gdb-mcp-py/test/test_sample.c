#include <stdio.h>

int global_var = 42;

int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int main(int argc, char *argv[]) {
    int local_var = 100;
    printf("Hello GDB MCP!\n");
    printf("Global variable: %d\n", global_var);
    printf("Local variable: %d\n", local_var);
    printf("Factorial(5) = %d\n", factorial(5));
    return 0;
}