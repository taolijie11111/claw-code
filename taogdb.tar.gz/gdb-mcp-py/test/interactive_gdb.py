#!/usr/bin/env python3
"""
GDB MCP 交互式命令行工具（稳定版）
使用 asyncio 事件和线程输入，确保 Ctrl+C 快速退出
"""

import asyncio
import json
import os
import sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
import signal

SERVER_SCRIPT = os.path.join(os.path.dirname(__file__), "server.py")

class GdbRepl:
    def __init__(self):
        self.session = None
        self.session_id = None
        self.exit_event = asyncio.Event()
        self.stdio_context = None
        self.read_stream = None
        self.write_stream = None
        self._closed = False

    async def start(self):
        if not os.path.exists(SERVER_SCRIPT):
            print(f"错误: 找不到 server.py 文件: {SERVER_SCRIPT}")
            return False

        print("=== GDB MCP 交互式工具 ===")
        print(f"使用服务器: {SERVER_SCRIPT}\n")

        server_params = StdioServerParameters(
            command="python3.11",
            args=[SERVER_SCRIPT],
            cwd=os.path.dirname(SERVER_SCRIPT)
        )

        try:
            self.stdio_context = stdio_client(server_params)
            self.read_stream, self.write_stream = await self.stdio_context.__aenter__()
            self.session = ClientSession(self.read_stream, self.write_stream)
            await self.session.__aenter__()
            await self.session.initialize()
            print("✓ MCP 连接成功")

            tools = await self.session.list_tools()
            print(f"✓ 可用工具: {[t.name for t in tools.tools]}")

            print("\n正在创建 GDB 调试会话...")
            result = await self.session.call_tool("start_session", {"working_directory": "."})
            data = json.loads(result.content[0].text)
            self.session_id = data.get("session_id")
            if not self.session_id:
                print("✗ 创建会话失败:", data)
                return False
            print(f"✓ GDB 会话创建成功，session_id = {self.session_id}")
            print("\n" + "=" * 60)
            print("输入 GDB MI 命令（如 -file-exec-and-symbols ./a.out），按回车发送")
            print("输入 'exit' 或 'quit' 退出，按 Ctrl+C 也可退出")
            print("=" * 60)
            return True
        except Exception as e:
            print(f"✗ 初始化失败: {e}")
            return False

    async def execute_command(self, command: str):
        if not self.session_id:
            print("会话 ID 无效，请重新启动。")
            return
        try:
            result = await self.session.call_tool(
                "execute_command",
                {"session_id": self.session_id, "command": command}
            )
            content = result.content[0].text
            try:
                resp = json.loads(content)
                if resp.get("error"):
                    print(f"错误: {resp['error']}")
                    return
                cls = resp.get("class", "unknown")
                print(f"class: {cls}")
                if "result" in resp and resp["result"]:
                    raw = resp["result"].get("raw", "")
                    if raw:
                        print(f"载荷: {raw}")
                if "records" in resp and resp["records"]:
                    for rec in resp["records"]:
                        if rec.get("type") == "output":
                            content_str = rec.get("content", "")
                            try:
                                content_str = content_str.encode().decode('unicode_escape')
                            except:
                                pass
                            print(f"输出: {content_str}")
                        elif rec.get("type") == "notification":
                            print(f"通知: {rec.get('content')}")
            except json.JSONDecodeError:
                print(f"原始响应: {content[:200]}")
        except Exception as e:
            print(f"命令执行异常: {e}")

    async def close(self):
        if self._closed:
            return
        self._closed = True

        if self.session_id:
            print("\n正在关闭 GDB 会话...")
            try:
                result = await self.session.call_tool("close_session", {"session_id": self.session_id})
                close_data = json.loads(result.content[0].text)
                print(f"关闭结果: {close_data}")
            except Exception as e:
                print(f"关闭会话时出错: {e}")
            self.session_id = None

        if self.session:
            try:
                await self.session.__aexit__(None, None, None)
            except:
                pass
        if self.stdio_context:
            try:
                await self.stdio_context.__aexit__(None, None, None)
            except:
                pass
        print("已退出。")

    async def repl_loop(self):
        # 设置信号处理器：设置退出事件
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGINT, lambda: self.exit_event.set())

        while not self.exit_event.is_set():
            try:
                # 使用 asyncio.to_thread 读取输入，并支持取消
                user_input = await asyncio.to_thread(input, "gdb> ")
                user_input = user_input.strip()
                if not user_input:
                    continue
                if user_input.lower() in ("exit", "quit", "q"):
                    self.exit_event.set()
                    break
                await self.execute_command(user_input)
            except (asyncio.CancelledError, KeyboardInterrupt):
                # 如果任务被取消，或者捕获到 KeyboardInterrupt，设置退出事件
                self.exit_event.set()
                break
            except EOFError:
                print("\n输入流关闭，退出。")
                self.exit_event.set()
                break
            except Exception as e:
                print(f"意外错误: {e}")
                self.exit_event.set()
                break

        # 清理
        await self.close()

async def main():
    repl = GdbRepl()
    if await repl.start():
        await repl.repl_loop()
    else:
        print("启动失败。")

if __name__ == "__main__":
    asyncio.run(main())