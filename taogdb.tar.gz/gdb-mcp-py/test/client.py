#!/usr/bin/env python3.11
import requests
import json
import time
import sys

BASE_URL = "http://localhost:8000"

class GDBMCPClient:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session_id = None
        self.session = requests.Session()

    def _call_tool(self, tool_name: str, params: dict) -> dict:
        payload = {
            "jsonrpc": "2.0",
            "id": str(int(time.time() * 1000)),
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": params
            }
        }
        try:
            # 关键修复：接口路径 /mcp，不是 /rpc
            response = self.session.post(
                f"{self.base_url}/mcp",
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": f"请求失败: {str(e)}"}
        except json.JSONDecodeError:
            return {"error": "响应非标准JSON"}

    def start_session(self, working_dir: str) -> dict:
        res = self._call_tool("start_session", {"working_directory": working_dir})
        if "result" in res and not res.get("error"):
            self.session_id = res["result"]["session_id"]
        return res

    def execute_command(self, command: str) -> dict:
        if not self.session_id:
            return {"error": "未创建会话，请先执行start_session"}
        return self._call_tool("execute_command", {"session_id": self.session_id, "command": command})

    def close_session(self) -> dict:
        if not self.session_id:
            return {"error": "无可用会话"}
        res = self._call_tool("close_session", {"session_id": self.session_id})
        if "result" in res and not res.get("error"):
            self.session_id = None
        return res

if __name__ == "__main__":
    client = GDBMCPClient(BASE_URL)
    print("=== 1. 创建 GDB 会话 ===")
    start_ret = client.start_session("/home/user/debug_project")
    print(json.dumps(start_ret, indent=2, ensure_ascii=False))
    if "error" in start_ret:
        sys.exit(1)

    print("\n=== 2. 执行GDB命令 ===")
    cmds = ["show version", "file ./a.out", "break main"]
    for c in cmds:
        print(f"\n> {c}")
        ret = client.execute_command(c)
        print(json.dumps(ret, indent=2, ensure_ascii=False))
        time.sleep(0.3)

    print("\n=== 3. 关闭会话 ===")
    print(json.dumps(client.close_session(), indent=2, ensure_ascii=False))