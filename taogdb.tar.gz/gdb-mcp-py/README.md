# GDB MCP Server (Python)

基于 MCP（Model Context Protocol）的 GDB 调试服务器，提供三个核心工具：
- `start_session`：启动一个 GDB 会话，可指定工作目录。
- `execute_command`：执行任意 GDB MI 命令（如 `-exec-run`, `-break-insert`）。
- `close_session`：关闭指定的 GDB 会话。

## 系统要求

- Python 3.11+（已测试 3.11）
- GDB（需在 `PATH` 中，或修改代码中 `gdb` 为绝对路径）
- 安装 `mcp` Python 包

## 安装与运行

1. 克隆或下载本项目，将所有 `.py` 文件放在同一目录下。
2. 安装依赖：
   ```bash
    python3.11 -m pip install -r requirements.txt

## 启动服务
python3.11 server.py

/home/00359039/Desktop/gdb-claw/gdb-mcp-py/interactive_gdb.py 基本功能测试脚本