#!/usr/bin/env python3.11
"""
GDB MCP Server - Claude CLI 长连接适配版
修复点：全局会话管理、无缓冲输出、长连接生命周期保持
"""
import sys
import os
import uuid
import subprocess
import threading
import queue
from datetime import datetime
from mcp.server.fastmcp import FastMCP

# ========== 1. 强制禁用标准输出缓冲（解决超时重启核心问题） ==========
# 行缓冲模式，确保 JSON-RPC 响应立即发送给 Claude CLI，避免超时导致进程被杀
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', buffering=1)

# ========== 2. 启动日志（用于验证进程是否被复用） ==========
LOG_PATH = "/tmp/gdb_mcp_server.log"
with open(LOG_PATH, "a", encoding="utf-8") as f:
    f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 服务器启动 PID:{os.getpid()}\n")

# ========== 3. MCP 服务器实例 ==========
mcp = FastMCP("gdbMCP")

# ========== 4. 全局会话管理（核心修复：全进程共享单例） ==========
class GDBSession:
    """单个 GDB 调试会话，绑定一个常驻 GDB 子进程"""
    def __init__(self, working_directory: str):
        self.session_id = str(uuid.uuid4())
        self.working_dir = working_directory
        self.output_queue = queue.Queue()
        self._stop_event = threading.Event()
        
        # 启动 GDB MI2 交互模式子进程
        self.process = subprocess.Popen(
            ["gdb", "--interpreter=mi2", "--quiet"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            cwd=self.working_dir,
            text=True,
            bufsize=1
        )
        
        # 后台线程持续读取 GDB 输出，不阻塞 MCP 通信
        self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
        self._reader_thread.start()

    def _read_loop(self):
        """后台循环读取 GDB 输出并存入队列"""
        while not self._stop_event.is_set() and self.process.poll() is None:
            line = self.process.stdout.readline()
            if not line:
                break
            self.output_queue.put(line.strip())

    def execute(self, command: str, timeout: float = 5.0) -> str:
        """执行 GDB 命令并返回完整输出"""
        if self.process.poll() is not None:
            raise RuntimeError("GDB 进程已退出")
        
        # 清空历史残留输出
        while not self.output_queue.empty():
            self.output_queue.get_nowait()
        
        # 写入命令并刷新
        self.process.stdin.write(command + "\n")
        self.process.stdin.flush()
        
        # 读取输出直到遇到 (gdb) 结束标记
        output = []
        try:
            while True:
                line = self.output_queue.get(timeout=timeout)
                output.append(line)
                if line.strip() == "(gdb)":
                    break
        except queue.Empty:
            pass
        
        return "\n".join(output)

    def close(self):
        """安全关闭会话和 GDB 进程"""
        self._stop_event.set()
        try:
            self.process.stdin.write("quit\n")
            self.process.stdin.flush()
            self.process.wait(timeout=2)
        except Exception:
            self.process.kill()


class SessionManager:
    """全局会话管理器，全进程唯一实例"""
    def __init__(self):
        self._sessions: dict[str, GDBSession] = {}

    def create(self, working_directory: str) -> str:
        """创建新会话，返回 session_id"""
        session = GDBSession(working_directory)
        self._sessions[session.session_id] = session
        return session.session_id

    def get(self, session_id: str) -> GDBSession | None:
        """获取指定会话"""
        return self._sessions.get(session_id)

    def delete(self, session_id: str) -> bool:
        """关闭并删除会话"""
        session = self._sessions.pop(session_id, None)
        if session:
            session.close()
            return True
        return False

# 【重中之重】模块顶层全局单例，整个服务器生命周期只有这一份
# 彻底解决「每次调用工具都新建管理器、会话全部丢失」的问题
session_manager = SessionManager()


# ========== 5. MCP 工具定义（完全兼容你现有调用方式） ==========
@mcp.tool()
def start_session(working_directory: str) -> dict:
    """创建新的 GDB 调试会话
    Args:
        working_directory: 调试工作目录绝对路径
    """
    session_id = session_manager.create(working_directory)
    return {
        "session_id": session_id,
        "status": "可用",
        "working_directory": working_directory
    }


@mcp.tool()
def execute_command(session_id: str, command: str) -> dict:
    """在指定会话中执行 GDB 命令
    Args:
        session_id: 会话 ID
        command: GDB MI 命令或普通命令
    """
    session = session_manager.get(session_id)
    if not session:
        return {"error": "Session not found", "session_id": session_id}
    
    try:
        output = session.execute(command)
        return {
            "session_id": session_id,
            "command": command,
            "output": output
        }
    except Exception as e:
        return {"error": str(e), "session_id": session_id}


@mcp.tool()
def close_session(session_id: str) -> dict:
    """关闭指定 GDB 调试会话
    Args:
        session_id: 会话 ID
    """
    success = session_manager.delete(session_id)
    if success:
        return {"session_id": session_id, "status": "已关闭"}
    else:
        return {"error": "Session not found", "session_id": session_id}


# ========== 6. 启动服务器（原生长连接模式） ==========
if __name__ == "__main__":
    # FastMCP 原生 stdio 长连接模式：自动维持事件循环，对话全程不退出
    # mcp.run()
    mcp.run(transport="streamable-http")