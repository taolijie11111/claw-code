from typing import Dict, Optional
from gdb_mi import GdbMiSession

class SessionManager:
    def __init__(self):
        self.sessions: Dict[str, GdbMiSession] = {}

    def create_session(self, working_dir: str = ".") -> str:
        """创建新会话，返回 session_id"""
        import uuid
        session_id = str(uuid.uuid4())
        session = GdbMiSession(working_dir)
        session.start()
        self.sessions[session_id] = session
        return session_id

    def get_session(self, session_id: str) -> Optional[GdbMiSession]:
        return self.sessions.get(session_id)

    def close_session(self, session_id: str) -> bool:
        session = self.sessions.pop(session_id, None)
        if session:
            session.close()
            return True
        return False